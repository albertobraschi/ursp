<?php
class Fooman_SameOrderInvoiceNumber_Helper_Data extends Mage_Core_Helper_Abstract
{

}