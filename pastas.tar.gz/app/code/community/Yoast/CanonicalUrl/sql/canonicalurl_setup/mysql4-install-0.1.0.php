<?php

Mage::getSingleton('catalog/url')->refreshRewrites();